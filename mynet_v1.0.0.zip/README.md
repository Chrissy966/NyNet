# MyNet App

Welcome to the MyNet social app.